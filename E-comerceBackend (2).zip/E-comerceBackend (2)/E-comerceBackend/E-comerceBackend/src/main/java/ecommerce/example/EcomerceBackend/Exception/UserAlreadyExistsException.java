package ecommerce.example.EcomerceBackend.Exception;

public class UserAlreadyExistsException extends  Exception{
}
