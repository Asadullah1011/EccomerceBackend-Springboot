package ecommerce.example.EcomerceBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EComerceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
